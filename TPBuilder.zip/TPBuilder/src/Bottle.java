

public class Bottle implements Packaging {

	private final static String BOTTLE = "Bottle";
	
    public Bottle() {
    	super();
    }
    
    public String getName() {
    	return BOTTLE;
    }

}