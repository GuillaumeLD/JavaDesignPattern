

public class Wrapper implements Packaging {

	private final static String WRAPPER = "Wrapper";
	
    public Wrapper() {
    	super();
    }

    public String getName() {
    	return WRAPPER;
    }
}