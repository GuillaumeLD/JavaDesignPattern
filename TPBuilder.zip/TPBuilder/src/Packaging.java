
//
//public abstract class Packaging {
//
//	String name = "";
//
//    public Packaging() {
//    	
//    }
//    
//    public Packaging(String name) {
//    	this.name = name;
//    }
//
//	public String getName() {
//		return name;
//	}
////
////	public void setName(String name) {
////		this.name = name;
////	}
//}

public interface Packaging {
	
	public String getName();
}